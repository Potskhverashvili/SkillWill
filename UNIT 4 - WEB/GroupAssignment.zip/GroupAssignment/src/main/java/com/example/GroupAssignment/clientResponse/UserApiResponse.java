package com.example.GroupAssignment.clientResponse;

import lombok.Data;

import java.util.List;

@Data
public class UserApiResponse {
    List<UserClientModel> data;
}
