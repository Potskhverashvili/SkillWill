package com.example.GroupAssignment.client;

import com.example.GroupAssignment.clientResponse.UserApiResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;


@FeignClient(value = "user-client", url = "https://reqres.in")
public interface UserClient {

    @GetMapping("/api/users")
    UserApiResponse getUsersFromApi();
}
