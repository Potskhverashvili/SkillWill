package com.example.GroupWork5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupWork5Application {

	public static void main(String[] args) {
		SpringApplication.run(GroupWork5Application.class, args);
	}

}
