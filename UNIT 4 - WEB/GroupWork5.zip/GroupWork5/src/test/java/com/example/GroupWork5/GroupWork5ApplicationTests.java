package com.example.GroupWork5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupWork5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
