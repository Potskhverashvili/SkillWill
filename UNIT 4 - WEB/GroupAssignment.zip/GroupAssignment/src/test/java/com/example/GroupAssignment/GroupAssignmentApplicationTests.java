package com.example.GroupAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
