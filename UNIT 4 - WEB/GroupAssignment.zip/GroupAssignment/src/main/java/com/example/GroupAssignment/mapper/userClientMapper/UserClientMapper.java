package com.example.GroupAssignment.mapper.userClientMapper;

import com.example.GroupAssignment.clientResponse.UserApiResponse;
import com.example.GroupAssignment.model.UserEntity;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class UserClientMapper {

    public static List<UserEntity> mapUserClientToUserEntity(UserApiResponse userApiResponse) {

        return userApiResponse.getData()
                .stream()
                .map(userData -> {
                    UserEntity userEntity = new UserEntity();
                    userEntity.setUserName(userData.getEmail());
                    userEntity.setName(userData.getFirstName());
                    userEntity.setSurname(userData.getLastName());
                    return userEntity;
                })
                .toList();
    }
}
