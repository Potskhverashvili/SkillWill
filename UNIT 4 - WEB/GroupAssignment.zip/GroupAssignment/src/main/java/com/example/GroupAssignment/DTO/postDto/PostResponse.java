package com.example.GroupAssignment.DTO.postDto;

import lombok.*;

@Data
@AllArgsConstructor
public class PostResponse {
    private Long id;
    private String text;
}
