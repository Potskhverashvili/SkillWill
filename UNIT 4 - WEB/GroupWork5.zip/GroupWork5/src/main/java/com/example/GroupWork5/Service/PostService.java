package com.example.GroupWork5.Service;

import org.springframework.stereotype.Service;

@Service
public class PostService {
}
